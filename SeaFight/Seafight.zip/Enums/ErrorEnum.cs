﻿namespace SeaFight.Enums
{
    public enum ReasonType
    {
        ResourceDictionaryError,
        ICollectionError,
        Exception,
        NullError,
        OtherError
    };
}
