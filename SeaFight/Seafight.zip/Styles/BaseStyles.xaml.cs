﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace SeaFight.Styles
{
    public partial class BaseStyles : ResourceDictionary
    {
        public BaseStyles()
        {
            InitializeComponent();
        }
    }
}
