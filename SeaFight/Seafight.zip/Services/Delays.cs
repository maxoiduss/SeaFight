﻿namespace SeaFight.Services
{
    public struct Delays
    {
        public const int delayS = 15;
        public const int delayMs = 500;
    }
}
